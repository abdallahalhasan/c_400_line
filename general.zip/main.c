/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*
#include <stdio.h>
#include<conio.h>
int main ()
{
int ilksayi,sonsayi,sayi;
printf("ilk sayiyi giriniz ");
scanf("%d", &ilksayi);
printf("son sayiyi giriniz ");
scanf("%d", &sonsayi);
for(sayi = ilksayi+1; sayi < sonsayi ; sayi++)
{  
    if(sayi % 2 == 1)
{
printf("%d \n ",sayi );
     }
   }
    return 0;
}
*/
/*
#include <stdio.h>
#include<conio.h>
int main ()
{
int x=5,y=7;
printf("x+y=%d",x+y);
getch();
return 0;
}
*/
/*
#include <stdio.h>

#include<conio.h>
int main ()  
{
    int x,y;
    printf("klaveyden iki sayı giriniz ");
    scanf ("%d %d ",&x,&y);
    printf("\n x+y=%d",x+y);
    printf("\n x-y=%d",x-y);
    printf("\n x*y=%d",x*y);
    printf("\n x/y=%d",x/y);
    getch();
    return 0; 
}
*/
/*
#include <stdio.h>
#include<conio.h>
int main () {
    int baslangic,bitis;
    printf("baslangic yilini  yaziniz");
    scanf( "%d",&baslangic);
    printf("bitis yilini yaziniz");
    scanf("%d",&bitis);
    printf("\n iki tarih arası fark=%d",bitis-baslangic);
    getch();
    return 0;
}
*/
/*
#include <stdio.h>
#include<conio.h>
int main () 
{
   float dolar,euro;
    printf("tl cinsinden Dolar değerini giriniz");
    scanf("%f",&dolar);
    printf("tl cinsinden Euro değerini giriniz");
    scanf("%f",&euro);
    printf("\n Dolar / Euro paritesi=%f", dolar / euro );
    getch();
    return 0; 
}
*/
/*
#include <stdio.h>
#include<conio.h>
int main () {
    float fahrenheit, celsius;
    printf(" sıcaklık değerinin fahrenheit cinsinden giriniz ");
    scanf("%f",&fahrenheit);
    printf("\n %2.1f fahrenheit = %2.1f celsius'dur.",fahrenheit,(fahrenheit-32)/1.8);
    getch ();
    return 0; 
}
*/
/*
#include <stdio.h>
#include<conio.h>
int main () {
    int sayi;
    printf("klaveyden bir sayı giriniz");
    scanf("%d",&sayi);
    if (sayi%2==1)
    printf("girdiğiniz sayı tek saydır");
    else 
    printf("girdiğiniz sayı çift saydır");
    getch();
    return 0;
}
*/
/*
#include <stdio.h>
#include<conio.h>
int main () {
    int sayi ;
    printf("klaveyden bir sayi giriniz ");
    scanf("%d",&sayi);
    if(sayi>0)
    printf("girdiğiniz sayi pozitif");
    else if (sayi<0)
    printf("girdiğiniz sayı negatif");
    else 
    printf("girdiğiniz sayı sıfıdır");
    getch ();
    return 0;
}
*/
/*
#include <stdio.h>
#include<conio.h>
int main () {
    int a,b,c;
    printf("klaveyden üç sayı giriniz");
    scanf("%d %d %d",&a,&b,&c);
    if ((a>b) && (b>c))
    printf("girdiğiniz sayi en büyük %d",a);
    else if (b>c)
    printf("girdiğiniz sayi en büyük %d",b);
    else
    printf("girdiğiniz sayi en büyük %d ",c);
    getch ();
    return 0; 
    
}
*/
/*
#include <stdio.h>
#include <conio.h>
int main () {
    int x, y, islem;
    printf ("\n klaveyden iki sayi giriniz :");
    scanf("%d %d", &x, &y);
    printf("\n bir islem kodu giriniz");
    scanf("%d",&islem);
    islem=getch();
    switch(islem)
        {
             case '+' :
                 printf("\n iki sayinin toplami=%d", x+y);
                 break;
             case '-' :
                 printf("\n iki sayini farki=%d", x-y);
                 break;
             case '*' :
                 printf ("\n iki saynini carpimi=%d", x*y);
                 break;
             case '/' :
                 printf("\n iki saynini bölümü=%f", (x*1.0)/y);
                 break;
             default:
                 break;
        }
       
         getch();
         return 0;
        
 }
*/
/*
#include <stdio.h>
#include <conio.h>
int main () {
    int x,y;
    printf("\n klaveyden bir x değeri giriniz");
    scanf("%d",&x);
    if(x>=0)
    y=x*x;
    else 
    y=2*x;
    printf("\n islem sonuncu =%d",y);
    getch();
    return 0; 
}
*/
/*
#include <stdio.h>
#include <conio.h>
int main () {
   int sayi,toplam=0;
   for(sayi=0;sayi<=100;sayi++)
   toplam=toplam+sayi;
   printf("\n toplam =%d ",toplam);
   getch();
   return 0;
*/
/*
#include <stdio.h>
#include <conio.h>
int main () {
    int n,f=1 ,sayac ;
    printf("\n sayiyi giriniz");
    scanf("%d",&n);
    for (sayac=1;sayac<=n;sayac++)
    f=f*sayac;
    printf("\n %d!=%d",n,f);
    getch();
    return 0;
}    
*/
/*
#include <stdio.h>
#include <conio.h>
int main () 
{
    int x,eb=0,ek=10001,sayac,toplam=0;
    float ortalama;
    printf("\n 1 ile 10000 arasinda sayilar giriniz \n\n");
    for (sayac=1;sayac<=5;sayac++)
    {
    printf("%d.sayiyi giriniz",sayac);
    scanf("%d",&x);
    if ((x>10000)||(x<1))continue;
    if(x>eb) eb=x;
    if (x<ek) ek=x;
    toplam=toplam+x;
    }
printf("\n klaveyden girilen en büyük sayi        =%d",eb);
printf("\n klaveyden girilen en küçük sayi        =%d",ek);
printf("\n klaveyden girilen sayiler toplami      =%d",toplam );
printf ("\nklaveyden girilen sayirlar ortalamsi     =%5.2f",toplam/5.);
getch();
return 0 ; 
}
*/
/*

#include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int main () 
{
   int age ;
printf("hazimin yaşı giriniz ");
scanf("%d",&age);
if (age>30)
printf("hazem büyük ");
else if (age ==30)
printf("hazem orta");
else 
printf("hazım küçük");

    getch();
    return 0 ; 
}
*/
/*
#include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int main () 
{
  int a,b;
  printf("\n klaveyden iki sayini giriniz ");
  scanf("%d %d",&a,&b);
  printf("\n a+b=%d",a+b);
  printf("\n a-b=%d",a-b);
  printf("\n a*b=%d",a*b);
  printf("\n a/b=%f",(a*1.0)/b);
  getch();
  return 0;
}
*/
/*
#include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int main () 
{
    float fiyat,indirim;
    printf("\n fiyati giriniz ");
    scanf("%f",&fiyat);
    printf("kaç indirim yapilyor giriniz");
    scanf("%f",&indirim);
    printf("\n ne kadar indirim uygulandı=%f",fiyat-(indirim*fiyat/100));
    getch ();
    return 0 ; 
}
*/
/*
#include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int main () 
{
   float uzunkenar,kisakenar,alan;
   printf("\n uzunkenar derğerini giriniz ");
   scanf("%f",&uzunkenar);
   printf("\n kisakenar değerini giriniz ");
   scanf("%f",&kisakenar);
   alan=uzunkenar*kisakenar;
   printf("\n alanin değerini =%.2f metrekardir",alan);
   getch();
   return 0 ;
}
   */
/*
#include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int main () 
{
     int ogrnot;
     printf("\n oğrenci notunu giriniz ");
     scanf("%d",&ogrnot);
        if (ogrnot>=0 && ogrnot<49)
        printf("oğerncinin harfı ....f");
            else if (ogrnot>=50 && ogrnot<59)
            printf("oğerncinin harfı....E");
                    else if (ogrnot>=60 && ogrnot<69)
                    printf("oğerncinin harfı ....D");
                      else if (ogrnot>=70 && ogrnot <79)
                      printf("oğerncinin harfı....C");
                          else if (ogrnot>=80 && ogrnot<89)
                          printf("oğerncinin harfı....B");
                             else if (ogrnot>=90 && ogrnot<=100)
                              printf("oğerncinin harfı...A");
                                else
                                printf("hatalı not birmişsiniz");
     getch();
     return 0; 

}
   */
/*
 #include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int main () 
{
   for(int x=0; x<=100;x++)

   {
      if (x%2==0)
   printf("%d \n ",x);
  
   }
   getch();
   return 0;
}
*/
/*

 #include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int main ()
{
    int sayi, i=0,toplam=0;
    printf("\n sayi giriniz");
    scanf("%d",&sayi);
        while(sayi!=0)
    {
        toplam=toplam+sayi;
        i++;
        printf("\n bir sonraki sayı ");
        scanf("%d",&sayi);
    }
    printf("\n ortalama= %f ",(float)(toplam)/i);
    getch();
    return 0 ;
}
*/
/*
 #include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int main () 
{
    int sayi, i=0,toplam=0;
    printf("\n sayi giriniz");
    scanf("%d",&sayi);
    for(  toplam=toplam+sayi;sayi!=0; i++)
    {
        printf("\n bir sonraki sayı ");
        scanf("%d",&sayi);
    }
     printf("\n ortalama= %f ",(float)(toplam)/i);
    getch();
    return 0 ;
    */
    /*
    #include <stdio.h>
#include <conio.h>
#include <stdbool.h>
int main ()  
{
   int  a , b;
   a=3;
   b=5;
   printf("a/b= %d",a/b);
  
   return 0;
    
}
*/
#include <stdio.h>

int main () {
    int a,b,c;
    printf(" klaveyden üç sayı giriniz \n ");
    scanf("%d %d %d",&a,&b,&c);
    if ((a>b) && (b>c))
    printf(" girdiğiniz sayi en büyük %d",a);
    else if (b>c)
    printf(" girdiğiniz sayi en büyük %d",b);
    else
    printf(" girdiğiniz sayi en büyük %d ",c);

    return 0;
}
