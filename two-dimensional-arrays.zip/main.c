/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define SIZE 10 

int main()
{
    /*
int arry[3][3]={{1,2,3},{4,5,6},{7,8,9}};    

for(int i=0;i<3;i++){
         for(int j=0;j<3;j++){
    printf("%d ",arry[i][j]);
         }
          printf("\n");
  }
  */
  /*
 int arry[3][3];
 for(int i=0;i<3;i++){
         for(int j=0;j<3;j++){
    scanf("%d",&arry[i][j]);
         }
          printf("\n");
  }
  for(int i=0;i<3;i++){
         for(int j=0;j<3;j++){
    printf("%d ",arry[i][j]);
         }
          printf("\n");
  
  }
  */
  
  
  
  /*
  int arry[3][5];
  int sum=0;
  int i,j;
         for(i=0;i<3;i++){
         for(j=0;j<5;j++){
         scanf("%d",&arry[i][j]);
         }
  }
        
  for(j=0;j<5;j++){
      for(i=0;i<3;i++){
          sum+=arry[i][j];
      }
      printf("%d ",sum);
      sum=0;
  }
      */
      //نقل المتغيرات من مصفوفة الى مصفوفة 
      /*
      int x [8];
      int  y[8] = {1,3,4,5,7,8,5,6};
      
      
      for(int i = 0 ; i<=7;i++){
          
          
          printf("x[%d]  =  %d\n",i,x[i]);
      }
      for(int i = 0; i<=7;i++){
          x[i]= y[i];
          printf("x[%d]  =  %d\n",i,x[i]);
          
      }
      */
      //DİZİLERİN ELEMENLERİNİ TOPLAMAK 
      /*
       int x [7];
      int  y [7] = {1,3,4,5,7,8,5};
      
      
      int toplam=0;
     float ortalam=0;
      for(int i = 0;i<=7;i++){
          
          toplam += y[i];

      }
            printf("%d\n",toplam);
            
         */
            
        
      
      
      //minimum
      
      
      int dizi [SIZE]={34,78,3456,123,654,57,7,57,8,9};
      int min=0;
      min=dizi[0];
     
      for(int i = 0; i<SIZE; i++){
            if(min > dizi[i])
            min = dizi[i];
          printf("%d\n",min);
          
          
          
      }
          printf("minimum = %d\n",min);
      //max
      int max=0;
      max=dizi[0];
       for(int i = 0; i<SIZE; i++){
            if(max < dizi[i])
            max = dizi[i];
          printf("%d\n",max);
          
          
          
      }
      printf("max = %d\n",max);
      
    
      
      /*
      
       int aram[SIZE]={34,78,3456,123,654,57,7,57,8,9};
       
       int sayi=0;
       int bulundu=0;
       printf("Aranacak sayiy giriniz : ");
       scanf("%d",&sayi);
       
       
       for (int i = 0 ; i<SIZE;i++){
           if(sayi==aram[i]){
           
           printf("aradiğinz sayi bulundu,%d dizinde %d.elemandır",SIZE,i+1);
           bulundu = 1; 
           break;
           
           }
        
           
       }
          if(bulundu==0)
           printf("aradiğinz sayiy yoktur ");
           
      */
      
      /*
       int dize[SIZE]={4,2,2,6,10,4,16,20,26,28};
       
      int tektoplam=0;
      int ciftToplam=0;
      int tek=0;
      float tekortalama=0;
      float ciftortalama=0;
      
      
      
      for(int i = 0; i<SIZE; i++){
          if(dize[i]%2 !=0 ){
              tektoplam +=dize[i];
              ++tek;
             
          }
          else{
              ciftToplam +=dize[i];
          }
          
      }
     
      printf("%d dizinde ,  %d tane  TEK sayiyi vardir ve bu sayıların toplamı   =%d\n",SIZE,tek,tektoplam);
        printf("%d dizinde ,  %d tane  ÇİFT sayiyi vardir ve bu sayıların toplamı =%d\n",SIZE, SIZE-tek,ciftToplam);

if(tek !=0 ){
      tekortalama=(float)tektoplam/(float)tek;
       printf("dizinde tek sayıların ortalamalarını  =%f\n",tekortalama);
}else
    printf("dizinde tek sayiyi yok\n");

      if(SIZE==tek){
           printf("dizinde çift sayiyi yok\n");
    
      }else
   
        ciftortalama=(float)ciftToplam/(float)(SIZE-tek);
       printf("dizinde çift sayıların ortalamalarını  =%f\n",ciftortalama);
      
      
      
      
      
      */
      }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  


